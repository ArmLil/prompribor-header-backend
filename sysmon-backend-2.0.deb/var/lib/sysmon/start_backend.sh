#!/bin/bash

. /var/lib/sysmon/nvm/nvm.sh
node /var/lib/sysmon/backend/index.js
